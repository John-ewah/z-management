package com.company;
class Car {
    private String name;
    private boolean engine;
    private int cylinder;
    private int wheels;
    private int velocity;

    public Car(String name, int cylinder) {
        this.name = name;
        this.engine = true;
        this.cylinder = cylinder;
        this.wheels = 4;
    }

    public String getName() {
        return name;
    }

    public boolean isEngine() {
        return engine;
    }

    public int getCylinder() {
        return cylinder;
    }

    public int getWheels() {
        return wheels;
    }
    public boolean startEngine(){

        System.out.println("engine not found. Unable to start");

        this.velocity=0;
        return false;
    }
    public void accelerate(int rate){
        if (startEngine() && rate>0 ){
            this.velocity=this.velocity+rate;
            System.out.println("The car accelerated to "+this.velocity);

        }else
        {
            System.out.println("The car wouldnt move");

        }}
    public void brake(){
        System.out.println(" Brake has been called. Car slowing down now");
    }
}
class Lamborghini extends Car{
    public Lamborghini() {
        super("Lamborghini", 12);
    }

    @Override
    public boolean startEngine() {
        System.out.println("Button has been pressed. Egine on");
        return true;
    }
}
class Toyota extends Car{
    public Toyota() {
        super("Toyota", 8);
    }

    @Override
    public boolean startEngine() {
        System.out.println("Key inserted. Engine starts");
        return true;
    }
}
class Kia extends Car{
    public Kia() {
        super("Kia",4);
    }


}

public class Main {

    public static void main(String[] args) {
	// write your code here
        for (int i=1; i<11;i++){
            Car car=randomCar();
            System.out.println("Car #"+i+" is a "+car.getName());
            System.out.println(car.startEngine());
        }
    }

public static Car randomCar(){
        int randomno=(int)(Math.random()*3) +1;
    System.out.println("Random number generated was #"+randomno);
    switch (randomno){
        case 1:
            return new Lamborghini();
        case 2:
            return new Toyota();
        case 3:
            return new Kia();

    }
    return null;


}}
